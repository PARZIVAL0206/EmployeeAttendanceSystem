<?php
require_once 'config/session.php';
session_destroy();
header('Location: /attendance-system/login.php');
exit;
