<?php
/**
 * Employee sidebar navigation.
 * Include this after starting the session and requiring config files.
 * Expects $_SESSION['full_name'], $_SESSION['employee_code'], $_SESSION['role'].
 */

// Count pending leave requests for badge
$pendingLeaveCount = 0;
try {
    $sidebarDb = getDB();
    $stmt = $sidebarDb->prepare("
        SELECT COUNT(*) FROM leaves
        WHERE employee_id = ? AND status = 'pending'
    ");
    $stmt->execute([$_SESSION['employee_id'] ?? 0]);
    $pendingLeaveCount = (int)$stmt->fetchColumn();
} catch (Exception $e) {
    // Non-fatal
}

$currentPage = basename($_SERVER['PHP_SELF']);

// Map internal role value to a readable label
$roleLabel = match($_SESSION['role'] ?? '') {
    'admin'    => 'Administrator',
    'employee' => 'Employee',
    default    => ucfirst($_SESSION['role'] ?? 'Employee'),
};

function empSidebarLink(string $href, string $icon, string $label, string $currentPage, string $badgeHtml = ''): string {
    $fileName = basename($href);
    $active   = ($fileName === $currentPage) ? ' active' : '';
    return "<a href=\"{$href}\" class=\"sidebar-link{$active}\">"
         . "<span class=\"sidebar-icon\">{$icon}</span>"
         . "<span class=\"sidebar-label\">{$label}</span>"
         . $badgeHtml
         . "</a>";
}

function empSidebarBadge(int $count): string {
    if ($count <= 0) return '';
    return "<span class=\"sidebar-badge\">{$count}</span>";
}
?>

<nav class="sidebar" id="empSidebar">
    <!-- Mobile close button -->
    <button class="sidebar-close" id="sidebarClose" aria-label="Close menu">&#10005;</button>

    <!-- Employee identity -->
    <div class="sidebar-user">
        <div class="sidebar-avatar">
            <?= strtoupper(substr($_SESSION['full_name'] ?? 'E', 0, 1)) ?>
        </div>
        <div class="sidebar-user-info">
            <div class="sidebar-user-name"><?= htmlspecialchars($_SESSION['full_name'] ?? 'Employee') ?></div>
            <div class="sidebar-user-code"><?= htmlspecialchars($_SESSION['employee_code'] ?? '') ?></div>
            <div class="sidebar-user-role"><?= htmlspecialchars($roleLabel) ?></div>
        </div>
    </div>

    <div class="sidebar-divider"></div>

    <!-- Navigation links -->
    <div class="sidebar-nav">
        <?= empSidebarLink('/attendance-system/employee/dashboard.php',     '&#127968;', 'Dashboard',         $currentPage) ?>
        <?= empSidebarLink('/attendance-system/employee/attendance.php',    '&#128344;', 'My Attendance',     $currentPage) ?>
        <?= empSidebarLink('/attendance-system/employee/history.php',       '&#128196;', 'Attendance History', $currentPage) ?>
        <?= empSidebarLink('/attendance-system/employee/schedule.php',      '&#128197;', 'My Schedule',       $currentPage) ?>
        <?= empSidebarLink('/attendance-system/employee/leave_request.php', '&#128203;', 'Leave Request',     $currentPage, empSidebarBadge($pendingLeaveCount)) ?>
        <?= empSidebarLink('/attendance-system/employee/leave_history.php', '&#128195;', 'Leave History',     $currentPage) ?>
        <?= empSidebarLink('/attendance-system/employee/profile.php',       '&#128100;', 'My Profile',        $currentPage) ?>
        <?= empSidebarLink('/attendance-system/employee/change_password.php','&#128274;','Change Password',   $currentPage) ?>
    </div>

    <div class="sidebar-divider"></div>

    <div class="sidebar-nav">
        <a href="/attendance-system/logout.php" class="sidebar-link sidebar-logout">
            <span class="sidebar-icon">&#128682;</span>
            <span class="sidebar-label">Logout</span>
        </a>
    </div>
</nav>

<!-- Mobile overlay -->
<div class="sidebar-overlay" id="sidebarOverlay"></div>

<style>
/* ── Employee sidebar styles ─────────────────────────────────── */
.sidebar {
    width: 240px;
    min-height: 100vh;
    background: linear-gradient(180deg, #004d40 0%, #00695c 60%, #00897b 100%);
    color: #fff;
    display: flex;
    flex-direction: column;
    position: fixed;
    top: 0; left: 0;
    z-index: 1000;
    transition: transform 0.28s cubic-bezier(.4,0,.2,1);
    box-shadow: 3px 0 16px rgba(0,0,0,0.18);
    overflow-y: auto;
}
.sidebar-close {
    display: none;
    background: none; border: none; color: #80cbc4;
    font-size: 1.3rem; cursor: pointer; padding: 0.6rem 1rem;
    text-align: right; width: 100%;
}
.sidebar-user {
    display: flex; align-items: center; gap: 0.75rem;
    padding: 1.4rem 1.2rem 1rem;
}
.sidebar-avatar {
    width: 40px; height: 40px; border-radius: 50%;
    background: rgba(255,255,255,0.2);
    display: flex; align-items: center; justify-content: center;
    font-size: 1.1rem; font-weight: 700; flex-shrink: 0;
}
.sidebar-user-name  { font-size: 0.88rem; font-weight: 700; line-height: 1.2; }
.sidebar-user-code  { font-size: 0.7rem; color: #80cbc4; letter-spacing: 0.05em; }
.sidebar-user-role  { font-size: 0.7rem; color: #b2dfdb; margin-top: 0.05rem; }
.sidebar-divider    { height: 1px; background: rgba(255,255,255,0.12); margin: 0.5rem 1rem; }
.sidebar-nav        { display: flex; flex-direction: column; padding: 0.4rem 0.6rem; }
.sidebar-link {
    display: flex; align-items: center; gap: 0.7rem;
    padding: 0.65rem 0.9rem; border-radius: 8px;
    color: rgba(255,255,255,0.82); text-decoration: none;
    font-size: 0.87rem; font-weight: 500;
    transition: background 0.18s, color 0.18s;
    position: relative; margin-bottom: 0.1rem;
}
.sidebar-link:hover  { background: rgba(255,255,255,0.12); color: #fff; }
.sidebar-link.active { background: rgba(255,255,255,0.18); color: #fff; font-weight: 700; }
.sidebar-icon  { font-size: 1rem; width: 22px; text-align: center; flex-shrink: 0; }
.sidebar-label { flex: 1; }
.sidebar-badge {
    background: #ef5350; color: #fff;
    font-size: 0.68rem; font-weight: 700;
    min-width: 18px; height: 18px;
    border-radius: 50px; display: inline-flex;
    align-items: center; justify-content: center;
    padding: 0 4px;
}
.sidebar-logout { color: #ef9a9a; }
.sidebar-logout:hover { background: rgba(239,83,80,0.18); color: #ef5350; }

/* Overlay */
.sidebar-overlay {
    display: none; position: fixed; inset: 0;
    background: rgba(0,0,0,0.45); z-index: 999;
}

/* Content offset */
.main-content { margin-left: 240px; }

/* Mobile responsive */
@media (max-width: 768px) {
    .sidebar { transform: translateX(-100%); }
    .sidebar.open { transform: translateX(0); }
    .sidebar-close { display: block; }
    .sidebar-overlay.open { display: block; }
    .main-content { margin-left: 0; }
}
</style>

<script>
(function () {
    var sidebar  = document.getElementById('empSidebar');
    var overlay  = document.getElementById('sidebarOverlay');
    var closeBtn = document.getElementById('sidebarClose');
    var openBtn  = document.getElementById('hamburgerBtn');

    function openSidebar()  { sidebar.classList.add('open'); overlay.classList.add('open'); }
    function closeSidebar() { sidebar.classList.remove('open'); overlay.classList.remove('open'); }

    if (openBtn)  openBtn.addEventListener('click', openSidebar);
    if (closeBtn) closeBtn.addEventListener('click', closeSidebar);
    if (overlay)  overlay.addEventListener('click', closeSidebar);
})();
</script>
